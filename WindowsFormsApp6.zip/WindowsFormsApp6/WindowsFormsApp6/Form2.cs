﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                int x = Convert.ToInt32(textBox1.Text);
                textBox1.Text = Convert.ToString(x * 1000);
            }

            if (radioButton2.Checked)
            {
                int x = Convert.ToInt32(textBox1.Text);
                textBox2.Text = Convert.ToString(x * 500);
            }

            if (radioButton3.Checked)
            {
                int x = Convert.ToInt32(textBox1.Text);
                textBox2.Text = Convert.ToString(x * 200);
            }
        }
    }
}
